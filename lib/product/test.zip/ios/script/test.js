require('UIView,UIImageView,UIColor,UIScreen')
require('YYApi,UIImage,UIButton')


var screenWidth = UIScreen.mainScreen().bounds().width;
var screenHeight = UIScreen.mainScreen().bounds().height;


defineClass("test:YSPBasePlugin", {

            onPluginInit:function(){
                self.observeModuleWithIdentifier('YYAboutViewController');
            },

            onModuleViewDidLoad:function(module){

                var size = 180;
                var imgView = UIImageView.alloc().initWithFrame({x: (screenWidth - size)/2, y: 120, width: size, height: size});

                var img = YYApi.res.image_plugin('apple','test');
                imgView.setImage(img);
                img.setTag(1);
                module.view().addSubview(imgView);

                module.versionLabel().setText('YSP插件测试版本')

                module.valueForKey('_copyright').setText('Copyright © 2016年 YSP All rights reserved (私有变量2222)');

            },
            onPluginDestroy:function() {
              var view = self.delegateModule().view().viewWithTag(1);
              view.removeFromSuperview();
            }
            });
