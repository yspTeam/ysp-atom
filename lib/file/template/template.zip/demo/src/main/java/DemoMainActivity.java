package ${package_name}$;

import android.app.Activity;
import android.os.Bundle;

public class DemoMainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.demo_main_activity);
    }
}
